export interface ITableInfo {
  isCheckedBoxAvailable?: boolean;
  isFilterAvailable?: boolean;
  isDisplayColumnAvailable?: boolean;
}
