import { IEducation } from './education';

export interface IUser {
  id: string;
  name: string;
  email: string;
  roleType: string;
  contact: string;
  city: string;
  country: string;
  state: string;
  pincode: string;
  gender: string;
  dob: string;
  hobbies: string[];
  isChecked: boolean;
  educationalDetail: IEducation[];
}
