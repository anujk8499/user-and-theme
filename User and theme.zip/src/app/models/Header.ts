export interface IHeader {
  key: string;
  label: string;
  isVisiable: boolean;
  isActiveLink?: boolean;
  isImage?: boolean;
  isColor?: boolean;
  isSimpleText?: boolean;
  activatedLink?: any;
  isEditable?: boolean;
}
