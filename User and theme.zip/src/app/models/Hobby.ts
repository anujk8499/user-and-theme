export interface IHobby {
  name: string;
  isSlected: boolean;
}
