export interface ITableButton {
  name: string;
  onClick: any;
  isDisable?: boolean;
}
