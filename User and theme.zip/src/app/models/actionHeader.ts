export interface IActionHeader {
  action: string;
  onClick: any;
  isVisible?: boolean;
}
