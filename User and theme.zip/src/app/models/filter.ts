export interface IFilter {
  key: string;
  label: string;
  type: string;
}
