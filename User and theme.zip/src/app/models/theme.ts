export interface ITheme {
  name: string;
  color: string;
  backGroundColor: string;
  date: string;
  image: string;
  default: boolean;
  isChecked: boolean;
  id: string;
}
