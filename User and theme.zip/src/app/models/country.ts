export interface ICountry {
  country: string;
  state: string[];
}
