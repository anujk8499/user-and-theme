export interface IEducation {
  degree: string;
  year: string;
  marks: string;
  isEdit?: boolean;
}
