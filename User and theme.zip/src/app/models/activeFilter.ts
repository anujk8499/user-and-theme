export interface IActiveFilter {
  key: string;
  label: string;
  value: string;
}
