import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './authServices/auth.service';
import { ThemeActionService } from './services/themeaction.service';
import { IdleTimeoutService } from './services/idle-timeout.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent implements OnInit {
  isLoggedIn: boolean = false;
  color = '';
  backGroundColor = '';

  constructor(
    private readonly authService: AuthService,
    private router: Router,
    private readonly themeActionService: ThemeActionService
  ) {}

  ngOnInit(): void {
    this.changeTheme();

    this.authService.data$.subscribe((data) => {
      this.isLoggedIn = data;
    });
    this.doInitialRouting();
  }

  doInitialRouting(): void {
    let currentLocation = window.location.pathname;
    if (currentLocation === '/' || currentLocation === '/login') {
      localStorage.setItem('isLoggedIn', 'false');
      this.isLoggedIn = false;
    } else {
      let isLoggedIn = localStorage.getItem('isLoggedIn');
      if (isLoggedIn === 'false') {
        this.router.navigate(['']);
      } else {
        this.isLoggedIn = true;
      }
    }
  }

  changeTheme(): void {
    this.themeActionService.data$.subscribe((data) => {
      this.color = data.color;
      this.backGroundColor = data.backGroundColor;
    });
  }
}
