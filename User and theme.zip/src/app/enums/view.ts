export enum View {
  update = 'update',
  create = 'create',
  summary = 'summary',
}
