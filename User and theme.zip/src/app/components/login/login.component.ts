import { Component, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { LoginUserService } from '../../services/loginUsers.service';
import { AuthService } from '../../authServices/auth.service';
import { emailRegx } from '../../global/validation';
import { IdleTimeoutService } from '../../services/idle-timeout.service';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ILoginUser } from '../../models/loginUser';
import { Idle } from '@ng-idle/core';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  public UserDetail: ILoginUser[];
  public showPassword: boolean;
  public notLoggedIn: boolean;
  loginForm!: FormGroup;
  constructor(
    private router: Router,
    private readonly loginUserService: LoginUserService,
    private readonly authService: AuthService
  ) {
    this.showPassword = false;
    this.notLoggedIn = false;
    this.UserDetail = [];
    this.initializeUserDetail();
    this.initializeLoginForm();
  }

  initializeLoginForm(): void {
    this.loginForm = new FormGroup({
      email: new FormControl('', [
        Validators.required,
        Validators.pattern(emailRegx),
      ]),
      password: new FormControl('', Validators.required),
    });
  }

  initializeUserDetail(): void {
    this.loginUserService
      .getUserDetail()
      .subscribe((userDetailArray: ILoginUser[]) => {
        this.UserDetail = userDetailArray;
      });
  }

  isEmailRequiredAndTouched(): boolean | undefined {
    const emailControl = this.loginForm.get('email');
    return emailControl?.hasError('required') && emailControl?.touched;
  }

  validEmail(): boolean | undefined {
    const emailControl = this.loginForm.get('email');
    return emailControl?.hasError('pattern') && emailControl?.touched;
  }

  onInputChange(): void {
    if (this.notLoggedIn == true) {
      this.notLoggedIn = false;
    }
  }

  togglePasswordVisibility(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    const email = this.loginForm.get('email')?.value;
    const password = this.loginForm.get('password')?.value;

    const index = this.UserDetail.findIndex(
      (loginUser) =>
        loginUser.email === email && loginUser.password === password
    );
    if (index != -1) {
      this.authService.login();
      localStorage.setItem('isLoggedIn', 'true');
      this.router.navigate(['user']);
    } else {
      this.notLoggedIn = true;
    }
  }
}
