import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IEducation } from '../../../../../models/education';
import { MatDialogRef } from '@angular/material/dialog';
import { IdService } from '../../../../../services/id.service';
import { marksRegex, yearRegx } from '../../../../../global/validation';
@Component({
  selector: 'app-education-detail-dialog',
  templateUrl: './education-detail-dialog.component.html',
  styleUrl: './education-detail-dialog.component.css',
})
export class EducationDetailDialogComponent {
  educationForm: FormGroup | any;
  educationDetail: IEducation = {
    degree: '',
    marks: '',
    year: '',
  };
  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<EducationDetailDialogComponent>
  ) {}

  ngOnInit(): void {
    this.initializeForm();
  }

  private initializeForm(): void {
    this.educationForm = this.fb.group({
      degree: ['', Validators.required],
      year: ['', [Validators.required, Validators.pattern(yearRegx)]],
      marks: ['', [Validators.required, Validators.pattern(marksRegex)]],
    });
  }

  onSubmit(): void {
    if (this.educationForm.valid) {
      this.educationDetail = this.educationForm.value;
      this.dialogRef.close(this.educationDetail);
    }
  }

  onClickCancel(): void {
    this.dialogRef.close(false);
  }
}
