import { Component, OnInit, Inject, Input, OnDestroy } from '@angular/core';
import { IUser } from '../../../../../models/user';
import { View } from '../../../../../enums/view';
import { FormGroup } from '@angular/forms';
import { IHobby } from '../../../../../models/hobby';
import { UserService } from '../../../../../services/user.service';
@Component({
  selector: 'app-basic-detail',
  templateUrl: './basic-detail.component.html',
  styleUrl: './basic-detail.component.css',
})
export class BasicDetailComponent {
  @Input() view!: View;
  @Input() userForm: FormGroup | any;
  @Input() userData!: IUser;
  allHobbies: IHobby[] = [];
  displayHobbies: IHobby[] = [];
  displaySelectedHobbies: IHobby[] = [];
  allSelectedHobbies: IHobby[] = [];
  isHobbyTouched: boolean = false;
  maxDate: Date;
  constructor(private readonly userService: UserService) {
    this.maxDate = new Date();
  }

  ngOnInit(): void {
    this.getAllHobbies();
  }

  getAllHobbies(): void {
    this.userService.getAllHobbies().subscribe((hobbies: IHobby[]) => {
      this.allHobbies = hobbies;
      this.userData.hobbies.forEach((hobbyName) => {
        this.displayHobbies.push({ name: hobbyName, isSlected: false });
        let index = this.allHobbies.findIndex(
          (allHobby) => allHobby.name == hobbyName
        );
        this.allHobbies.splice(index, 1);
      });
      this.allHobbies = [...this.allHobbies];
    });
  }
  onClickMoveHobbyRight(): void {
    this.allSelectedHobbies.forEach((hobby) => {
      const index = this.allHobbies.findIndex((allHobby) => allHobby == hobby);
      if (index != -1) {
        hobby.isSlected = false;
        this.allHobbies.splice(index, 1);
        this.displayHobbies.push(hobby);
        this.userData.hobbies.push(hobby.name);
      }
    });
    this.allSelectedHobbies = [];
  }

  onClickMoveAllHobbyRight(): void {
    this.allHobbies.forEach((hobby) => {
      hobby.isSlected = false;
      this.displayHobbies.push(hobby);
      this.userData.hobbies.push(hobby.name);
    });
    this.allHobbies = [];
    this.allSelectedHobbies = [];
  }

  onClickMoveHobbyLeft(): void {
    this.displaySelectedHobbies.forEach((hobby) => {
      const index = this.displayHobbies.findIndex((dHobby) => dHobby == hobby);
      const index1 = this.userData.hobbies.findIndex(
        (userHobby) => userHobby == hobby.name
      );
      hobby.isSlected = false;
      if (index != -1) {
        this.displayHobbies.splice(index, 1);
        this.allHobbies.push(hobby);
        this.userData.hobbies.splice(index1, 1);
      }
    });
    this.displaySelectedHobbies = [];
  }

  onClickMoveAllHobbyLeft(): void {
    this.displayHobbies.forEach((hobby) => {
      hobby.isSlected = false;
      this.allHobbies.push(hobby);
      let index = this.userData.hobbies.findIndex(
        (userHobby) => userHobby == hobby.name
      );
      if (index != -1) {
        this.userData.hobbies.splice(index, 1);
      }
    });

    this.displaySelectedHobbies = [];
    this.displayHobbies = [];
  }

  onAllHobbiesSelected(selectedHobby: IHobby): void {
    const index = this.allSelectedHobbies.findIndex(
      (hobby) => hobby == selectedHobby
    );

    if (index == -1) {
      selectedHobby.isSlected = true;
      this.allSelectedHobbies.push(selectedHobby);
    } else {
      selectedHobby.isSlected = false;
      this.allSelectedHobbies.splice(index, 1);
    }
  }

  onDisplayHobbySelected(selectedHobby: IHobby): void {
    const index = this.displaySelectedHobbies.findIndex(
      (hobby) => hobby == selectedHobby
    );

    if (index == -1) {
      selectedHobby.isSlected = true;
      this.displaySelectedHobbies.push(selectedHobby);
    } else {
      selectedHobby.isSlected = false;
      this.displaySelectedHobbies.splice(index, 1);
    }
  }
}
