import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ICountry } from '../../../../../models/country';
import { UserService } from '../../../../../services/user.service';
import { IUser } from '../../../../../models/user';
@Component({
  selector: 'app-address-detail',
  templateUrl: './address-detail.component.html',
  styleUrl: './address-detail.component.css',
})
export class AddressDetailComponent implements OnInit {
  @Input() userForm!: FormGroup;
  @Input() view: any;
  public states: string[] = [];
  public countries: ICountry[] = [];
  constructor(private readonly userService: UserService) {}
  ngOnInit(): void {
    this.getCountries();
  }

  getCountries(): void {
    this.userService
      .getAllCountriesAndStateDetails()
      .subscribe((countryStateDetail: ICountry[]) => {
        this.countries = countryStateDetail;
        this.countries.forEach((data) => {
          if (data.country === this.userForm.get('country')?.value) {
            this.states = data.state;
          }
        });
      });
  }
  updateStateDropdown(): void {
    let country = this.userForm.get('country')?.value;
    let countryDetail: ICountry | undefined = this.countries.find(
      (countryData) => countryData.country == country
    );
    if (countryDetail) {
      this.states = countryDetail.state;
      const firstState = this.states.length > 0 ? this.states[0] : null;
      this.userForm.get('state')?.setValue(firstState);
    }
  }
}
