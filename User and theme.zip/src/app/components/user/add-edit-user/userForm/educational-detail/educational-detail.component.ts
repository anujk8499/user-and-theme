import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { IEducation } from '../../../../../models/education';
import { IHeader } from '../../../../../models/header';
import { IFilter } from '../../../../../models/filter';
import { Sort } from '@angular/material/sort';
import { IActionHeader } from '../../../../../models/actionHeader';
import { MatDialog } from '@angular/material/dialog';
import { EducationDetailDialogComponent } from '../education-detail-dialog/education-detail-dialog.component';
import { DeleteDialogComponent } from '../../../../shared/delete-dialog/delete-dialog.component';
import { ITableInfo } from '../../../../../models/tableInfo';
import { IUser } from '../../../../../models/user';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { marksRegex, yearRegx } from '../../../../../global/validation';
import { ITableButton } from '../../../../../models/tableButton';
import { TableComponent } from '../../../../shared/table/table.component';
import { View } from '../../../../../enums/view';
@Component({
  selector: 'app-educational-detail',
  templateUrl: './educational-detail.component.html',
  styleUrl: './educational-detail.component.css',
})
export class EducationalDetailComponent implements OnInit {
  @ViewChild('tableChild') tableChild!: TableComponent;
  @Input() view!: View;
  educationDetail: IEducation[] = [];
  @Input() userData!: IUser;
  @Input() isEducationTabValid!: { isValid: boolean };
  initSortData: Sort = { active: 'Degree', direction: 'asc' };
  educationForm: FormGroup | any;
  isDataRecieved: boolean = false;
  isEducationFormTouched: boolean = false;
  tableInfo: ITableInfo = {
    isCheckedBoxAvailable: false,
    isFilterAvailable: true,
    isDisplayColumnAvailable: true,
  };

  tableButtons: ITableButton[] = [
    {
      name: 'Add',
      onClick: () => {
        this.onClickAdd();
      },
      isDisable: false,
    },
  ];

  tableActions: IActionHeader[] = [
    {
      action: 'delete',
      onClick: (education: IEducation) => {
        this.onClickDelete(education);
      },
      isVisible: true,
    },
  ];
  tableHeaders: IHeader[] = [
    {
      key: 'degree',
      label: 'Degree',
      isVisiable: true,
      isSimpleText: false,
      isEditable: true,
    },
    {
      key: 'year',
      label: 'Year',
      isVisiable: true,
      isSimpleText: false,
      isEditable: true,
    },
    {
      key: 'marks',
      label: 'Marks',
      isVisiable: true,
      isSimpleText: false,
      isEditable: true,
    },
  ];

  filterHeaders: IFilter[] = [
    {
      key: 'degree',
      label: 'Degree',
      type: 'text',
    },
    {
      key: 'year',
      label: 'Year',
      type: 'text',
    },
    {
      key: 'marks',
      label: 'Marks',
      type: 'text',
    },
  ];
  constructor(private dialog: MatDialog, private fb: FormBuilder) {}

  ngOnInit(): void {
    this.userData.educationalDetail.forEach((education) => {
      this.educationDetail.push({ ...education });
    });
    this.isDataRecieved = true;
    if (this.view == 'summary') {
      this.tableInfo = {
        ...this.tableInfo,
        isFilterAvailable: false,
        isDisplayColumnAvailable: false,
      };
      this.tableHeaders.forEach((header) => (header.isSimpleText = true));
      this.tableButtons = [];
      this.tableActions = [];
    }
    this.initializeEducationForm();
  }

  initializeEducationForm(): void {
    this.educationForm = this.fb.group({
      degree: ['', Validators.required],
      year: ['', [Validators.required, Validators.pattern(yearRegx)]],
      marks: ['', [Validators.required, Validators.pattern(marksRegex)]],
    });
  }

  onClickAdd(): void {
    const dialogRef = this.dialog.open(EducationDetailDialogComponent, {
      width: '500px',
      height: '300px',
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.educationDetail.push(result);
        this.userData.educationalDetail.push(result);
        this.educationDetail = [...this.educationDetail];
      }
    });
  }

  onClickDelete(education: IEducation): void {
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      width: '300px',
      data: { name: education.degree },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        let index = this.educationDetail.findIndex(
          (eduDetail) => eduDetail == education
        );

        if (index != -1) {
          this.educationDetail.splice(index, 1);
          this.educationDetail = [...this.educationDetail];
          this.userData.educationalDetail.splice(index, 1);
        }
      }
    });
  }
}
