import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import { IUser } from '../../../models/user';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material/dialog';
import {
  FormGroup,
  FormBuilder,
  AbstractControl,
  Validators,
} from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { FormatdateService } from '../../../services/formatdate.service';
import {
  nameRegx,
  contactRegx,
  emailRegx,
  pincodeRegx,
  cityRegx,
} from '../../../global/validation';
import { View } from '../../../enums/view';
import { IdService } from '../../../services/id.service';
import { BasicDetailComponent } from './userForm/basic-detail/basic-detail.component';
import { IEducation } from '../../../models/education';
import { EducationalDetailComponent } from './userForm/educational-detail/educational-detail.component';
import { SnackbarService } from '../../../services/snackbar.service';

@Component({
  selector: 'app-add-edit-user',
  templateUrl: './add-edit-user.component.html',
  styleUrl: './add-edit-user.component.css',
})
export class AddEditUserComponent implements OnInit {
  @ViewChild('basicDetailChild') basicDetailChild!: BasicDetailComponent;
  @ViewChild('educationDetailChild')
  educationDetailChild!: EducationalDetailComponent;
  selectedTabIndex: number = 0;
  isForUpdate: boolean = false;
  userForm: FormGroup | any;
  userData: IUser = {
    id: '',
    name: '',
    email: '',
    roleType: '',
    gender: '',
    dob: '',
    country: '',
    state: '',
    contact: '',
    hobbies: [],
    isChecked: false,
    educationalDetail: [],
    city: '',
    pincode: '',
  };
  isEducationTabValid: { isValid: boolean } = { isValid: true };
  summary: View = View.summary;
  update: View = View.update;
  create: View = View.create;
  constructor(
    private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<AddEditUserComponent>,
    private readonly formateDateService: FormatdateService,
    @Inject(MAT_DIALOG_DATA)
    private data: {
      userDataDetail: IUser;
      allUserData: IUser[];
    },
    private readonly idService: IdService,
    private readonly snackbarService: SnackbarService
  ) {}

  ngOnInit(): void {
    this.checkForUpdateDialogOrNot();
    this.intializeForm();
  }

  checkForUpdateDialogOrNot(): void {
    if (this.data?.userDataDetail !== undefined) {
      this.isForUpdate = true;
      this.userData = { ...this.data.userDataDetail };
      this.userData.hobbies = [];
      this.userData.educationalDetail = [];
      this.data.userDataDetail.hobbies.forEach((hobby) => {
        this.userData.hobbies.push(hobby);
      });
      this.data.userDataDetail.educationalDetail.forEach((education) => {
        this.userData.educationalDetail.push(education);
      });
    } else {
      this.isForUpdate = false;
    }
  }

  uniqueEmailIdValidator(): Object {
    return (control: AbstractControl) => {
      if (this.isForUpdate === true) {
        return null;
      }
      const userEmail = control.value;
      const allUserDataArray: IUser[] = this.data.allUserData;

      const isUnique = !allUserDataArray.some(
        (userData) => userData.email === userEmail
      );

      return isUnique ? null : { notUnique: true };
    };
  }

  intializeForm(): void {
    this.userForm = this.formBuilder.group({
      name: [
        this.userData.name,
        [Validators.required, Validators.pattern(nameRegx)],
      ],
      email: [
        this.userData.email,
        [
          Validators.required,
          Validators.pattern(emailRegx),
          this.uniqueEmailIdValidator(),
        ],
      ],
      roleType: [this.userData.roleType, [Validators.required]],
      contact: [
        this.userData.contact,
        [Validators.required, Validators.pattern(contactRegx)],
      ],
      country: [this.userData.country, [Validators.required]],
      state: [this.userData.state, [Validators.required]],
      gender: [this.userData.gender, [Validators.required]],
      dob: [new Date(this.userData.dob), [Validators.required]],
      pincode: [
        this.userData.pincode,
        [Validators.required, Validators.pattern(pincodeRegx)],
      ],
      city: [
        this.userData.city,
        [Validators.required, Validators.pattern(cityRegx)],
      ],
    });
  }
  onContinueClick(): void {
    if (this.selectedTabIndex == 0) {
      this.basicDetailChild.isHobbyTouched = true;
    }
    if (this.selectedTabIndex == 1) {
      this.educationDetailChild.isEducationFormTouched = true;
    }
    if (
      (this.selectedTabIndex == 0 && this.isBasicFormValid(true)) ||
      (this.selectedTabIndex == 1 && this.isEducationFormValid()) ||
      (this.selectedTabIndex == 2 && this.isAddressFormValid(true))
    ) {
      this.selectedTabIndex += 1;
    }
  }
  onBackClick() {
    this.selectedTabIndex -= 1;
  }

  onClickCancel() {
    this.dialogRef.close(false);
  }

  onClickSave() {
    this.userData.name = this.userForm.get('name')?.value;
    this.userData.email = this.userForm.get('email')?.value;
    this.userData.roleType = this.userForm.get('roleType')?.value;
    this.userData.contact = this.userForm.get('contact')?.value;
    this.userData.city = this.userForm.get('city').value;
    this.userData.country = this.userForm.get('country')?.value;
    this.userData.state = this.userForm.get('state')?.value;
    this.userData.pincode = this.userForm.get('pincode').value;
    this.userData.gender = this.userForm.get('gender').value;
    this.userData.dob = this.formateDateService.getFormattedData(
      new Date(this.userForm.get('dob').value)
    );

    this.userData.hobbies = [];
    this.basicDetailChild.displayHobbies.forEach((hobby) => {
      this.userData.hobbies.push(hobby.name);
    });
    this.userData.educationalDetail = [];
    this.educationDetailChild.educationDetail.forEach(
      (education: IEducation) => {
        this.userData.educationalDetail.push(education);
      }
    );
    this.userData.isChecked = false;
    if (!this.isForUpdate) {
      this.idService.getNextUserId().subscribe((nextId: number) => {
        this.userData.id = String(nextId);
        this.dialogRef.close(this.userData);
        this.snackbarService.createSnackbar(
          `${this.userData.name} added sucessfully`
        );
      });
    } else {
      this.snackbarService.createSnackbar(
        `${this.userData.name} updated successfully`
      );
      this.dialogRef.close(this.userData);
    }
  }

  isBasicFormValid(isContinueValidation: boolean): boolean {
    const nameControl = this.userForm.get('name');
    const emailControl = this.userForm.get('email');
    const roleTypeControl = this.userForm.get('roleType');
    const contactControl = this.userForm.get('contact');
    const genderControl = this.userForm.get('gender');
    const dobControl = this.userForm.get('dob');
    // Check if all required fields are valid
    const isNameValid = nameControl.valid;
    const isEmailValid = emailControl.valid;
    const isRoleTypeValid = roleTypeControl.valid;
    const isContactValid = contactControl.valid;
    const isgenderValid = genderControl.valid;
    const isDobValid = dobControl.valid;

    // Return overall form validity
    if (isContinueValidation) {
      if (!isNameValid) {
        nameControl.markAsTouched();
        emailControl.markAsTouched();
        roleTypeControl.markAsTouched();
        contactControl.markAsTouched();
        genderControl.markAsTouched();
        dobControl.markAsTouched();
      }
    }

    return (
      isNameValid &&
      isEmailValid &&
      isRoleTypeValid &&
      isContactValid &&
      isgenderValid &&
      isDobValid &&
      this.userData.hobbies.length > 0
    );
  }

  isEducationFormValid(): boolean {
    return (
      this.userData.educationalDetail.length > 0 &&
      this.isEducationTabValid.isValid
    );
  }

  isAddressFormValid(isContinueValidation: boolean): boolean {
    const cityControl = this.userForm.get('city');
    const stateControl = this.userForm.get('state');
    const countryControl = this.userForm.get('country');
    const pincodeControl = this.userForm.get('pincode');

    // Check if all required fields are valid
    const isCityValid = cityControl.valid;
    const isStateValid = stateControl.valid;
    const isCountryValid = countryControl.valid;
    const isPincodeValid = pincodeControl.valid;

    if (isContinueValidation) {
      cityControl.markAsTouched();
      stateControl.markAsTouched();
      countryControl.markAsTouched();
      pincodeControl.markAsTouched();
    }

    // Return overall form validity

    return isCityValid && isStateValid && isCountryValid && isPincodeValid;
  }

  onTabChange(currentTabIndex: number): void {
    if (currentTabIndex == 3) {
      for (const controlName in this.userForm.controls) {
        if (this.userForm.controls.hasOwnProperty(controlName)) {
          this.userForm.get(controlName).disable();
        }
      }
    } else {
      for (const controlName in this.userForm.controls) {
        if (this.userForm.controls.hasOwnProperty(controlName)) {
          this.userForm.get(controlName).enable();
        }
      }
    }

    if (this.selectedTabIndex >= 2) {
      this.userData.educationalDetail = [];
      this.educationDetailChild.educationDetail.forEach((educdation) => {
        this.userData.educationalDetail.push(educdation);
      });
    }
  }
}

// export enum ViewEnum {
//   isForUpdate = 'update',
//   isForSummary = 'summary',
//   isForCreate = 'create',
// }
