import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { HttpClientModule } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatIcon } from '@angular/material/icon';
import { MatTable } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatOptionModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';
import { SharedModule } from '../shared/shared.module';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
import { AddEditUserComponent } from './add-edit-user/add-edit-user.component';
import { MatTabsModule } from '@angular/material/tabs';

import { BasicDetailComponent } from './add-edit-user/userForm/basic-detail/basic-detail.component';
import { AddressDetailComponent } from './add-edit-user/userForm/address-detail/address-detail.component';
import { EducationalDetailComponent } from './add-edit-user/userForm/educational-detail/educational-detail.component';
import { EducationDetailDialogComponent } from './add-edit-user/userForm/education-detail-dialog/education-detail-dialog.component';
@NgModule({
  declarations: [
    UserComponent,
    AddEditUserComponent,
    BasicDetailComponent,
    AddressDetailComponent,
    EducationalDetailComponent,
    EducationDetailDialogComponent,
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatToolbarModule,
    MatButtonModule,
    HttpClientModule,
    MatTableModule,
    MatIcon,
    MatTable,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatOptionModule,
    MatIconModule,
    SharedModule,
    MatRadioModule,
    MatDatepickerModule,
    MatTabsModule,
  ],
  providers: [provideNativeDateAdapter()],
})
export class UserModule {}
