import { Component, OnInit, ViewChild } from '@angular/core';
import { IUser } from '../../models/user';
import { UserService } from '../../services/user.service';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

import { DeleteDialogComponent } from '../shared/delete-dialog/delete-dialog.component';
import { IHeader } from '../../models/header';
import { FormGroup } from '@angular/forms';
import { IFilter } from '../../models/filter';
import { Sort } from '@angular/material/sort';
import { IActionHeader } from '../../models/actionHeader';
import { AddEditUserComponent } from './add-edit-user/add-edit-user.component';
import { ITableButton } from '../../models/tableButton';
import { TableComponent } from '../shared/table/table.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
})
export class UserComponent implements OnInit {
  @ViewChild('tableChild') tableChild!: TableComponent;
  userDataArray: IUser[] = [];
  isDataRecieved: boolean = false;
  initSortData: Sort = { active: 'Name', direction: 'asc' };
  tableActions: IActionHeader[] = [
    {
      action: 'edit',
      onClick: (userData: IUser) => {
        this.onClickEdit(userData);
      },
      isVisible: true,
    },
    {
      action: 'delete',
      onClick: (userData: IUser) => {
        this.onClickDelete(userData);
      },
      isVisible: true,
    },
  ];

  tableButtons: ITableButton[] = [
    {
      name: 'Add',
      onClick: () => {
        this.onClickAddUser();
      },
      isDisable: false,
    },
    {
      name: 'Delete',
      onClick: () => {
        this.tableChild.clickDeleteSelection();
      },
      isDisable: true,
    },
    {
      name: 'Download',
      onClick: () => {
        this.tableChild.onClickDownload();
      },
      isDisable: true,
    },
  ];

  filterHeaders: IFilter[] = [
    {
      key: 'name',
      label: 'Name',
      type: 'text',
    },
    {
      key: 'email',
      label: 'Email',
      type: 'text',
    },
    {
      key: 'contact',
      label: 'Contact',
      type: 'text',
    },
    {
      key: 'city',
      label: 'City',
      type: 'text',
    },
    {
      key: 'country',
      label: 'Country',
      type: 'select',
    },
    {
      key: 'state',
      label: 'State',
      type: 'select',
    },

    {
      key: 'pincode',
      label: 'Pincode',
      type: 'text',
    },
    {
      key: 'dob',
      label: 'DOB',
      type: 'date',
    },
    {
      key: 'gender',
      label: 'Gender',
      type: 'radio',
    },
  ];

  tableHeaders: IHeader[] = [
    {
      key: 'name',
      label: 'Name',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'email',
      label: 'Email',
      isVisiable: true,
      isSimpleText: true,
    },

    {
      key: 'roleType',
      label: 'Role-type',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'contact',
      label: 'Contact',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'city',
      label: 'City',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'country',
      label: 'Country',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'state',
      label: 'State',
      isVisiable: true,
      isSimpleText: true,
    },

    {
      key: 'pincode',
      label: 'Pincode',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'gender',
      label: 'Gender',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'dob',
      label: 'DOB',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'hobbies',
      label: 'Hobbies',
      isVisiable: true,
      isSimpleText: true,
    },
  ];

  constructor(
    private readonly userService: UserService,
    public dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.initializeUserData();
  }

  initializeUserData(): void {
    this.userService.getAllUserData().subscribe((userDataArray: IUser[]) => {
      this.userDataArray = userDataArray;
      this.isDataRecieved = true;
    });
  }

  onClickAddUser(): void {
    const dialogRef = this.dialog.open(AddEditUserComponent, {
      width: '800px',
      height: '650px',
      data: {
        allUserData: this.userDataArray,
      },
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.userService.addUser(result).subscribe(() => {
          this.initializeUserData();
        });
      }
    });
  }

  onClickEdit(editUserData: IUser): void {
    const dialogRef = this.dialog.open(AddEditUserComponent, {
      width: '800px',
      height: '650px',
      data: {
        userDataDetail: editUserData,
        allUserData: this.userDataArray,
      },
      disableClose: true,
    });
    dialogRef.afterClosed().subscribe((result: IUser) => {
      if (result) {
        this.userService.editUser(result.id, result).subscribe(() => {
          this.initializeUserData();
        });
      }
    });
  }

  onClickDelete(userData: IUser): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.closeOnNavigation = true;

    dialogConfig.disableClose = true;
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      width: '300px',
      data: { name: userData.name },
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.userService.deleteUser(userData.id).subscribe(() => {
          this.initializeUserData();
        });
      }
    });
  }
  onClickDeleteSeletedUser() {}
  onClickDownloadSelectedUser() {}
}
