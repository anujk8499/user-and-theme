import { Component, Output, EventEmitter, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../authServices/auth.service';
import { ThemeActionService } from '../../../services/themeaction.service';
import { ITheme } from '../../../models/theme';
import { CurrentLocationService } from '../../../services/current-location.service';
import { Routes } from '@angular/router';
import { IdleTimeoutService } from '../../../services/idle-timeout.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent implements OnInit {
  public color!: string;
  public backgroundColor!: string;
  public image!: string;
  public selectedButtonCss = {
    'background-color': 'grey',
  };
  public selectedNavButton!: string;
  constructor(
    private router: Router,
    private readonly authService: AuthService,
    private readonly themeActionService: ThemeActionService,
    private readonly currentLocationService: CurrentLocationService,
    private readonly idleTimeoutService: IdleTimeoutService
  ) {}

  ngOnInit(): void {
    this.initializeCurrentNavbarButton();
    this.changeTheme();
  }

  changeTheme(): void {
    this.themeActionService.data$.subscribe((data) => {
      this.color = data.color;
      this.backgroundColor = data.backGroundColor;
      this.image = data.image;
    });
  }

  initializeCurrentNavbarButton(): void {
    //to get the selected nav button name when user refreshes the app
    this.selectedNavButton =
      this.currentLocationService.getCurrentLocationRoute();
  }

  logout(): void {
    this.authService.logout();
    this.idleTimeoutService.stopTimeout();
    localStorage.setItem('isLoggedIn', 'false');
  }

  onUserClick(): void {
    this.selectedNavButton = 'user';
    this.router.navigate(['user']);
  }

  onThemeClick(): void {
    this.selectedNavButton = 'theme';
    this.router.navigate(['theme']);
  }
}
