import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css',
})
export class FooterComponent {
  footerLabel: string =
    'Copyright © CodeInsight Technologies. 2022. All Rights Reserved. ';
  currentDate: Date = new Date();
  currentYear = this.currentDate.getFullYear();
  constructor() {}
}
