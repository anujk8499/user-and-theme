import {
  Component,
  Input,
  Output,
  EventEmitter,
  ViewChild,
  OnInit,
  AfterViewInit,
} from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ThemeActionService } from '../../../services/themeaction.service';
import { Sort, SortDirection } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { IHeader } from '../../../models/header';
import { MatSort } from '@angular/material/sort';
import { DownloadService } from '../../../services/download.service';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { IFilter } from '../../../models/filter';
import { UserService } from '../../../services/user.service';
import { ICountry } from '../../../models/country';
import { FormatdateService } from '../../../services/formatdate.service';
import { IActiveFilter } from '../../../models/activeFilter';
import { IActionHeader } from '../../../models/actionHeader';
import { ITableInfo } from '../../../models/tableInfo';
import { ITableButton } from '../../../models/tableButton';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrl: './table.component.css',
})
export class TableComponent implements OnInit, AfterViewInit {
  @Input() editForm: FormGroup | any;
  @Input() tableTitle: string = '';
  @Input() tableData: any[] = [];
  @Input() filterHeaders: IFilter[] = [];
  @Input() tableHeaders: IHeader[] = [];
  @Input() initSortData!: Sort;
  @Input() tableActions: IActionHeader[] = [];
  @Input() tableButtons: ITableButton[] = [];
  @Input() isEducationTabValid!: { isValid: boolean };
  @Input() tableInfo: ITableInfo = {
    isCheckedBoxAvailable: true,
    isFilterAvailable: true,
    isDisplayColumnAvailable: true,
  };

  public displayedColumns: string[] = [];
  public dataSource = new MatTableDataSource<any>();
  public isFilterFormVisible: boolean = false;
  public isHeaderDisplayList: boolean = false;
  public isCountryDataRecieved: boolean = false;
  public filterForm: FormGroup | any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  public color = '';
  public backGroundColor = '';
  public countries: ICountry[] = [];
  public states: string[] = [];
  public activeFilter: IActiveFilter[] = [];
  public isAllChecked: boolean = false;
  public currentEditColumnName!: string;
  private isAnyEditCellActive: boolean = false;
  constructor(
    private readonly themeActionService: ThemeActionService,
    private formBuilder: FormBuilder,
    private readonly userService: UserService,
    private readonly formatDate: FormatdateService,
    private readonly downloadService: DownloadService
  ) {}

  ngOnInit(): void {
    this.changeTheme();
    this.initializeDisplayedColumns();
    this.filterForm = this.formBuilder.group({});
    this.initializeFilterForm();
    this.initializeCountries();
    this.dataSource.sort = this.sort;
  }

  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.initFilterPredicate();
  }

  ngOnChanges(): void {
    this.dataSource.data = this.tableData;

    this.defaultSort();
  }

  defaultSort(): void {
    this.sortData(this.initSortData);
  }

  initializeCountries(): void {
    this.userService
      .getAllCountriesAndStateDetails()
      .subscribe((data: ICountry[]) => {
        this.countries = data;
      });
  }

  initializeDisplayedColumns(): void {
    if (this.tableInfo.isCheckedBoxAvailable) {
      this.displayedColumns.push('selection');
    }

    this.tableHeaders.forEach((header) => {
      this.displayedColumns.push(header.label);
    });
    if (this.tableActions.length) {
      this.displayedColumns.push('actions');
    }
  }

  initFilterPredicate(): void {
    this.dataSource.filterPredicate = (data, filter) => {
      let result = true;

      let filterObject = JSON.parse(filter);

      Object.keys(filterObject).forEach((key) => {
        let column = this.filterHeaders.find((filter) => filter.key == key);
        if (column?.type == 'date' && column && filterObject[key]) {
          const formattedDate = this.formatDate.getFormattedData(
            new Date(filterObject[key])
          );
          result = result && data[key].includes(formattedDate);
        }
        if (
          (column?.type == 'text' || column?.type == 'select') &&
          column &&
          filterObject[key]
        ) {
          result =
            result &&
            data[key].includes(filterObject[key].trim().toLowerCase());
        }
        if (column?.type == 'radio' && filterObject[key]) {
          const ans = data[key] == filterObject[key];
          result = result && ans;
        }
      });

      return result;
    };
  }

  initializeFilterForm(): void {
    for (let i = 0; i < this.filterHeaders.length; i++) {
      this.filterForm.addControl(
        this.filterHeaders[i].key,
        this.formBuilder.control('')
      );
    }
  }

  changeTheme(): void {
    this.themeActionService.data$.subscribe((data) => {
      this.color = data.color;
      this.backGroundColor = data.backGroundColor;
    });
  }

  sortData(sort: Sort): void {
    this.initSortData = sort;
    const data = this.dataSource.data;

    const isAsc = sort.direction == 'asc';
    if (!sort.active || sort.direction === '') {
      return;
    } else {
      const header = this.tableHeaders.find(
        (tHeader) => tHeader.label == sort.active
      );
      if (header) {
        this.dataSource.data = data.sort((a, b) => {
          if (header.key == 'date' || header.key == 'dob') {
            const ans =
              (new Date(a[header.key]) < new Date(b[header.key]) ? -1 : 1) *
              (isAsc ? 1 : -1);
            return ans;
          }
          return (a[header?.key] < b[header.key] ? -1 : 1) * (isAsc ? 1 : -1);
        });
      }
    }
  }

  toggleVisibleForm(): void {
    this.isFilterFormVisible = !this.isFilterFormVisible;
  }

  clearFilterForm(): void {
    this.activeFilter = [];
    this.resetFilterForm();
    this.onClickFilter();
    this.isFilterFormVisible = false;
  }

  onClickFilter(): void {
    this.isFilterFormVisible = false;

    this.activeFilter = [];
    this.filterHeaders.forEach((label) => {
      if (this.filterForm.get(label.key).value != '') {
        if (label.type == 'date') {
          this.activeFilter.push({
            key: label.key,
            label: label.label,
            value: this.formatDate.getFormattedData(
              new Date(this.filterForm.get(label.key).value)
            ),
          });
        } else {
          this.activeFilter.push({
            key: label.key,
            label: label.label,
            value: this.filterForm.get(label.key).value,
          });
        }
      }
    });
    this.dataSource.filter = JSON.stringify(this.filterForm.value);
  }

  onClickChangeColumn(header: IHeader): void {
    header.isVisiable = !header.isVisiable;
    this.displayedColumns = [];

    if (this.tableInfo.isCheckedBoxAvailable) {
      this.displayedColumns.push('selection');
    }
    this.tableHeaders.forEach((header) => {
      if (header.isVisiable) {
        this.displayedColumns.push(header.label);
      }
    });
    if (this.tableActions.length) this.displayedColumns.push('actions');
    this.displayedColumns = [...this.displayedColumns];
  }

  toggleDisplayColumnButton(): void {
    this.isHeaderDisplayList = !this.isHeaderDisplayList;
  }

  updateStateDropdown(): void {
    this.filterForm.get('state').setValue('');
    let country = this.filterForm.get('country')?.value;
    let countryDetail: ICountry | undefined = this.countries.find(
      (countryData) => countryData.country == country
    );
    if (countryDetail) {
      this.states = countryDetail.state;
    }
  }

  resetFilterForm(): void {
    this.activeFilter = [];
    this.filterHeaders.forEach((filter) => {
      this.filterForm.get(filter.key).setValue('');
    });
  }

  onClickCancelActiveFilter(key: string): void {
    let ind = -1;
    this.activeFilter.forEach((filter, index) => {
      if (filter.key == key) {
        if (key == 'country') {
          this.states = [];
          this.filterForm.get('state').setValue('');
        }
        this.filterForm.get(key).setValue('');
        ind = index;
      }
    });
    this.activeFilter.splice(ind, 1);
    this.activeFilter = [...this.activeFilter];

    this.onClickFilter();
  }

  clickDeleteSelection(): void {
    this.dataSource.data = this.dataSource.data.filter(
      (ele) => ele['isChecked'] == false
    );
    this.dataSource.data = [...this.dataSource.data];
    this.isAllChecked = false;
    this.tableButtons.forEach((button) => {
      if (button.name == 'Delete') {
        button.isDisable = true;
      }
      if (button.name == 'Download') {
        button.isDisable = true;
      }
    });
  }

  onChangeCheckbox(data: any): void {
    data['isChecked'] = !data['isChecked'];
    const index = this.dataSource.data.findIndex(
      (tableData) => tableData['isChecked'] == true
    );
    if (index == -1) {
      this.tableButtons.forEach((button) => {
        if (button.name == 'Delete') {
          button.isDisable = true;
        }
        if (button.name == 'Download') {
          button.isDisable = true;
        }
      });
    } else {
      this.tableButtons.forEach((button) => {
        if (button.name == 'Delete') {
          button.isDisable = false;
        }
        if (button.name == 'Download') {
          button.isDisable = false;
        }
      });
    }
  }

  onAllSectionCheckboxClick(): void {
    const pageIndex = this.paginator.pageIndex;
    const pageSize = this.paginator.pageSize;
    const totalIteration = Math.min(
      this.dataSource.data.length - pageIndex * pageSize,
      pageSize
    );
    if (!this.isAllChecked) {
      for (
        let i = pageIndex * pageSize;
        i < pageIndex * pageSize + totalIteration;
        i++
      ) {
        let ele = this.dataSource.data[i];
        if (ele['default'] == true) {
          ele['isChecked'] == false;
        } else ele['isChecked'] = true;
      }
      this.tableButtons.forEach((button) => {
        if (button.name == 'Delete') {
          button.isDisable = false;
        }
        if (button.name == 'Download') {
          button.isDisable = false;
        }
      });
    } else {
      for (
        let i = pageIndex * pageSize;
        i < pageIndex * pageSize + totalIteration;
        i++
      ) {
        let ele = this.dataSource.data[i];
        ele['isChecked'] = false;
      }
      this.tableButtons.forEach((button) => {
        if (button.name == 'Delete') {
          button.isDisable = true;
        }
        if (button.name == 'Download') {
          button.isDisable = true;
        }
      });
    }

    this.isAllChecked = !this.isAllChecked;
  }

  onPageChange(event: any): any {
    this.dataSource.data.forEach((data) => {
      data['isChecked'] = false;
    });
    this.isAllChecked = false;
    this.tableButtons.forEach((button) => {
      if (button.name == 'Delete') {
        button.isDisable = true;
      }
      if (button.name == 'Download') {
        button.isDisable = true;
      }
    });
  }

  onClickDownload() {
    this.downloadService.exportToCSV(this.tableHeaders, this.dataSource.data);
  }

  onClickEdit(element: any, column: IHeader): void {
    if (this.isAnyEditCellActive) {
      return;
    }
    this.isEducationTabValid.isValid = false;

    this.editForm.get(column['key']).setValue(element[column['key']]);

    this.isAnyEditCellActive = true;
    element['isEdit'] = true;
    this.currentEditColumnName = column.key;
    this.dataSource.data = [...this.dataSource.data];
  }

  onBlur(element: any, column: any): void {
    if (!this.editForm.get(column['key']).valid) {
      return;
    }
    this.isEducationTabValid.isValid = true;

    element[column['key']] = this.editForm.get(column['key'])?.value;
    this.isAnyEditCellActive = false;
    element['isEdit'] = false;
  }

  onPressEnter(element: any, column: any): void {
    if (!this.editForm.get(column['key']).valid) {
      return;
    }
    this.isEducationTabValid.isValid = true;

    element[column['key']] = this.editForm.get(column['key'])?.value;
    this.isAnyEditCellActive = false;
    element['isEdit'] = false;
  }
}
