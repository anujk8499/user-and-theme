import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrl: './timer.component.css',
})
export class TimerComponent implements OnInit {
  public message: string = 'do you want to continue';
  public countdown: number = 5;
  private countdownInterval: any;
  private dialogTimerRef: any;
  constructor(private dialogRef: MatDialogRef<TimerComponent>) {}

  ngOnInit(): void {
    this.initializeTimerCount();
  }

  initializeTimerCount(): void {
    this.countdownInterval = setInterval(() => {
      if (this.countdown > 0) {
        this.countdown--;
      } else {
        clearInterval(this.countdownInterval);
      }
    }, 1000);

    this.dialogTimerRef = setTimeout(() => {
      if (this.dialogRef) {
        this.dialogRef.close();
      }
    }, 5000);
  }

  ngOnDestroy(): void {
    clearInterval(this.countdownInterval);
    clearTimeout(this.dialogTimerRef);
  }

  onLogoutClick(): void {
    this.dialogRef.close('logout');
  }
  onContinueClick(): void {
    this.dialogRef.close('continue');
  }
}
