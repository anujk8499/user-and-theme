import { Component, Output, EventEmitter, Input, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ITheme } from '../../../models/theme';
import { ThemeService } from '../../../services/theme.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { IdService } from '../../../services/id.service';
import { FormatdateService } from '../../../services/formatdate.service';
import {
  MatSnackBar,
  MatSnackBarHorizontalPosition,
  MatSnackBarVerticalPosition,
} from '@angular/material/snack-bar';
import { SnackbarService } from '../../../services/snackbar.service';

@Component({
  selector: 'app-add-edit-theme',
  templateUrl: './add-edit-theme.component.html',
  styleUrl: './add-edit-theme.component.css',
})
export class AddEditThemeComponent implements OnInit {
  themeForm: FormGroup | any;
  isDataRecieved: boolean = false;
  isForUpdated: boolean = false;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';
  themeData: ITheme = {
    id: '',
    color: '',
    backGroundColor: '',
    image: '',
    name: '',
    default: false,
    date: '',
    isChecked: false,
  };
  constructor(
    private fb: FormBuilder,
    private readonly themeService: ThemeService,
    private router: Router,
    private route: ActivatedRoute,
    private readonly idService: IdService,
    private readonly formateDateService: FormatdateService,
    private readonly snackbarService: SnackbarService
  ) {}

  ngOnInit(): void {
    this.checkforUpdateComponentOrNot();
  }

  checkforUpdateComponentOrNot(): void {
    const index = parseInt(this.route.snapshot.params['id'], 10);
    if (index) {
      this.isForUpdated = true;
      this.themeService
        .getThemeById(String(index))
        .subscribe((theme: ITheme) => {
          this.themeData = theme;
          this.initializeForm();
        });
    } else {
      this.initializeForm();
    }
  }

  initializeForm(): void {
    this.themeForm = this.fb.group({
      color: [this.themeData.color, [Validators.required]],
      colorPicker: [this.themeData.color, [Validators.required]],
      backGroundColor: [this.themeData.backGroundColor, [Validators.required]],
      backGroundColorPicker: [
        this.themeData.backGroundColor,
        [Validators.required],
      ],
      image: [this.themeData.image, [Validators.required]],
      name: [this.themeData.name, [Validators.required]],
    });
    this.isDataRecieved = true;
  }

  onColorChange(): void {
    const color = this.themeForm.get('colorPicker').value;
    this.themeForm.get('color').setValue(color);
  }

  onBackGroundColorChange(): void {
    const backGroundColor = this.themeForm.get('backGroundColorPicker').value;
    this.themeForm.get('backGroundColor').setValue(backGroundColor);
  }

  onColorInputChange(): void {
    const color = this.themeForm.get('color').value;

    this.themeForm.get('colorPicker').setValue(color);
  }

  onBackGroundColorInputChange(): void {
    const backGroundColor = this.themeForm.get('backGroundColor').value;
    this.themeForm.get('backGroundColorPicker').setValue(backGroundColor);
  }

  onClickClear(): void {
    this.router.navigate(['theme']);
  }

  onSubmit(): void {
    this.themeData.name = this.themeForm.get('name')?.value;
    this.themeData.backGroundColor =
      this.themeForm.get('backGroundColor')?.value;
    this.themeData.color = this.themeForm.get('color')?.value;

    this.themeData.image = this.themeForm.get('image')?.value;
    this.themeData.isChecked = false;
    if (this.isForUpdated) {
      this.themeService
        .editTheme(this.themeData.id, this.themeData)
        .subscribe(() => {
          this.snackbarService.createSnackbar(
            `${this.themeData.name} updated successfully.`
          );
          this.router.navigate(['theme']);
        });
    } else {
      this.themeData.date = this.formateDateService.getFormattedData(
        new Date()
      );
      this.idService.getNextThemeId().subscribe((id: number) => {
        this.themeData.id = String(id);
        this.themeService.addTheme(this.themeData).subscribe();
        this.snackbarService.createSnackbar(
          `${this.themeData.name} added successfully.`
        );
        this.router.navigate(['theme']);
      });
    }
  }
}
