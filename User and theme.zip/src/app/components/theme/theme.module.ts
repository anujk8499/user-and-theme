import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ThemeRoutingModule } from './theme-routing.module';
import { ThemeComponent } from './theme.component';
import { SharedModule } from '../shared/shared.module';
import { AddEditThemeComponent } from './add-edit-theme/add-edit-theme.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { NgxColorsModule } from 'ngx-colors';
import { MatButtonModule } from '@angular/material/button';

-MatButtonModule;
@NgModule({
  declarations: [ThemeComponent, AddEditThemeComponent],
  imports: [
    CommonModule,
    ThemeRoutingModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    NgxColorsModule,
  ],
})
export class ThemeModule {}
