import { Component, OnInit, ViewChild } from '@angular/core';
import { ThemeService } from '../../services/theme.service';
import { ITheme } from '../../models/theme';
import { TableComponent } from '../shared/table/table.component';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DeleteDialogComponent } from '../shared/delete-dialog/delete-dialog.component';
import { ThemeActionService } from '../../services/themeaction.service';
import { IHeader } from '../../models/header';
import { IFilter } from '../../models/filter';
import { Sort } from '@angular/material/sort';
import { ITableButton } from '../../models/tableButton';
import { IActionHeader } from '../../models/actionHeader';
@Component({
  selector: 'app-theme',
  templateUrl: './theme.component.html',
  styleUrl: './theme.component.css',
  providers: [TableComponent],
})
export class ThemeComponent implements OnInit {
  @ViewChild('tableChild') tableChild!: TableComponent;
  themeDataArray: ITheme[] = [];
  initSortData: Sort = { active: 'Date', direction: 'asc' };
  currentDefaultThemeData: ITheme = {
    id: '',
    color: '',
    backGroundColor: '',
    image: '',
    name: '',
    default: false,
    date: '',
    isChecked: false,
  };

  tableButtons: ITableButton[] = [
    {
      name: 'Add',
      onClick: () => {
        this.onClickAddTheme();
      },
      isDisable: false,
    },
    {
      name: 'Delete',
      onClick: () => {
        this.tableChild.clickDeleteSelection();
      },
      isDisable: true,
    },
    {
      name: 'Download',
      onClick: () => {
        this.tableChild.onClickDownload();
      },
      isDisable: true,
    },
  ];

  filterHeaders: IFilter[] = [
    {
      key: 'name',
      label: 'Name',
      type: 'text',
    },
    {
      key: 'color',
      label: 'Color',
      type: 'text',
    },
    {
      key: 'backgroundColor',
      label: 'BackgroundColor',
      type: 'text',
    },
    {
      key: 'date',
      label: 'Date',
      type: 'date',
    },
  ];

  tableHeaders: IHeader[] = [
    {
      key: 'name',
      label: 'Name',
      isVisiable: true,
      isActiveLink: true,
      activatedLink: (theme: ITheme) => this.onClickEdit(theme),
      isSimpleText: false,
    },
    {
      key: 'color',
      label: 'Color',
      isColor: true,
      isVisiable: true,
      isSimpleText: false,
    },
    {
      key: 'backGroundColor',
      label: 'Background-color',
      isColor: true,
      isVisiable: true,
      isSimpleText: false,
    },

    {
      key: 'date',
      label: 'Date',
      isVisiable: true,
      isSimpleText: true,
    },
    {
      key: 'image',
      label: 'Image',
      isVisiable: true,
      isImage: true,
      isSimpleText: false,
    },
  ];
  //here thumb_up action is for apply theme
  tableActions: IActionHeader[] = [
    {
      action: 'delete',
      onClick: (theme: ITheme) => this.onClickDelete(theme),
    },
    {
      action: 'thumb_up',
      onClick: (theme: ITheme) => this.onClickApply(theme),
    },
  ];
  isDataRecieved: boolean = false;

  constructor(
    private readonly themeService: ThemeService,
    private router: Router,
    private dialog: MatDialog,
    private readonly themeActionService: ThemeActionService
  ) {}

  ngOnInit(): void {
    this.getAllTheme();
  }

  getAllTheme(): void {
    this.themeService.getAllTheme().subscribe((themeData: ITheme[]) => {
      this.themeDataArray = themeData;
      this.themeDataArray = [...this.themeDataArray];
      this.isDataRecieved = true;
      const index = this.themeDataArray.findIndex(
        (ele) => ele.default === true
      );
      if (index != -1) {
        this.currentDefaultThemeData = this.themeDataArray[index];
        this.themeActionService.setSelectedTheme(this.currentDefaultThemeData);
      }
    });
  }

  onClickAddTheme(): void {
    this.router.navigate(['theme/add']);
  }

  onClickDelete(theme: ITheme): void {
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      width: '300px',
      data: { name: theme.name },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.themeService.deleteTheme(theme.id).subscribe((data: any) => {
          this.getAllTheme();
        });
      }
    });
  }

  onClickEdit(theme: ITheme): void {
    this.router.navigate(['theme/edit', theme.id]);
  }

  onClickApply(theme: ITheme): void {
    const newTheme: ITheme = theme;
    newTheme.default = true;
    this.currentDefaultThemeData.default = false;

    this.themeService
      .editTheme(this.currentDefaultThemeData.id, this.currentDefaultThemeData)
      .subscribe(() => {});
    this.themeService.editTheme(theme.id, newTheme).subscribe(() => {
      this.getAllTheme();
    });

    this.themeActionService.setSelectedTheme(theme);
  }
}
