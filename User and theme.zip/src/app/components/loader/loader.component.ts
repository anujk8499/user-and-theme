import { Component, OnInit } from '@angular/core';
import { LoaderService } from '../../services/loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrl: './loader.component.css',
})
export class LoaderComponent implements OnInit {
  public isLoading: boolean = false;
  constructor(private readonly loaderService: LoaderService) {}

  ngOnInit(): void {
    this.initializeLoader();
  }

  initializeLoader(): void {
    this.loaderService.isLoading.subscribe((data) => {
      this.isLoading = data;
    });
  }
}
