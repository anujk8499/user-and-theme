// auth.service.ts

import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isLoggedIn = false;

  private dataSubject = new BehaviorSubject<boolean>(this.isLoggedIn);
  public data$: Observable<boolean> = this.dataSubject.asObservable();

  login(): void {
    this.dataSubject.next(true);
  }

  logout(): void {
    this.dataSubject.next(false);
  }

  isLoggedInUser(): boolean {
    return this.isLoggedIn;
  }
}
