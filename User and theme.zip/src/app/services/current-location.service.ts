import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CurrentLocationService {
  constructor() {}

  getCurrentLocationRoute(): string {
    let currentLocation = window.location.pathname;

    if (currentLocation.includes('user')) {
      return 'user';
    } else if (currentLocation.includes('theme')) {
      return 'theme';
    }
    return '';
  }
}
