import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { baseUrl } from '../global/http-url';
import { Observable } from 'rxjs';
import { IUser } from '../models/user';
import { IHobby } from '../models/hobby';
import { ICountry } from '../models/country';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  private userDataUrl: string = `${baseUrl}/userData`;
  private hobbiesUrl: string = `${baseUrl}/hobbies`;
  private countryStateUrl: string = `${baseUrl}/countrystates`;
  constructor(private http: HttpClient) {}

  ngOnInit(): void {}

  getAllUserData(): Observable<IUser[]> {
    return this.http.get<IUser[]>(this.userDataUrl);
  }

  deleteUser(id: string): Observable<any> {
    return this.http.delete(`${this.userDataUrl}/${id}`, {
      responseType: 'text',
    });
  }

  addUser(user: IUser): Observable<any> {
    return this.http.post(`${this.userDataUrl}`, user);
  }

  editUser(id: string, user: IUser): Observable<any> {
    return this.http.put(`${this.userDataUrl}/${id}`, user);
  }

  getUserById(id: string): Observable<IUser> {
    return this.http.get<IUser>(`${this.userDataUrl}/${id}`);
  }

  getAllHobbies(): Observable<IHobby[]> {
    return this.http.get<IHobby[]>(this.hobbiesUrl);
  }

  getAllCountriesAndStateDetails(): Observable<ICountry[]> {
    return this.http.get<ICountry[]>(this.countryStateUrl);
  }
}
