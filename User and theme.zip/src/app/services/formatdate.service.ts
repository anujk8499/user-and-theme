import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class FormatdateService {
  constructor() {}

  getFormattedData(inputDate: Date): string {
    const month = String(inputDate.getMonth() + 1).padStart(2, '0');
    const day = String(inputDate.getDate()).padStart(2, '0');
    const year = inputDate.getFullYear();

    return `${month}/${day}/${year}`;
  }
}
