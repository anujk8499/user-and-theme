import { Injectable, OnDestroy } from '@angular/core';
import { Subject, Observable, takeUntil } from 'rxjs';
import { AuthService } from '../authServices/auth.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSnackBarRef } from '@angular/material/snack-bar';
import { TimerComponent } from '../components/timer/timer.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
@Injectable({
  providedIn: 'root',
})
export class IdleTimeoutService implements OnDestroy {
  private timeoutDuration: number = 10 * 1000 * 60; // 10 minutes in milliseconds
  private timeoutId: any;
  private popupTimeId: any;
  public snackBarRef: any;
  private destroy$: Subject<void> = new Subject<void>();
  constructor(
    private readonly authService: AuthService,
    private router: Router,
    private dialog: MatDialog
  ) {}

  startTimeout(): void {
    this.timeoutId = setTimeout(() => {
      this.authService.logout();
      this.router.navigate(['login']);
    }, this.timeoutDuration);
    this.popupTimeId = setTimeout(() => {
      let dialogRef = this.dialog.open(TimerComponent, {
        width: '300px',
        height: '200px',
        disableClose: true,
      });
      dialogRef.afterClosed().subscribe((result) => {
        if (result == 'continue') {
          this.resetTimeout();
        } else {
          this.stopTimeout();
        }
      });
    }, this.timeoutDuration - 5 * 1000);
  }

  resetTimeout(): void {
    clearTimeout(this.timeoutId);
    clearTimeout(this.popupTimeId);
    this.startTimeout();
  }

  stopTimeout(): void {
    this.authService.logout();
    this.router.navigate(['login']);
    clearTimeout(this.timeoutId);
    clearTimeout(this.popupTimeId);
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
