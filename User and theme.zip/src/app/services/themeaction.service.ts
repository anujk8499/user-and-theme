import { Injectable } from '@angular/core';
import { ITheme } from '../models/theme';
import { BehaviorSubject, Observable } from 'rxjs';
import { ThemeService } from './theme.service';
@Injectable({
  providedIn: 'root',
})
export class ThemeActionService {
  private theme: ITheme = {
    id: '',
    color: '',
    backGroundColor: '',
    image: '',
    name: '',
    default: false,
    date: '',
    isChecked: false,
  };
  private dataSubject = new BehaviorSubject<ITheme>(this.theme);
  public data$: Observable<ITheme> = this.dataSubject.asObservable();

  constructor(private readonly themeService: ThemeService) {
    this.initializeThemeData();
  }

  initializeThemeData(): void {
    this.themeService.getAllTheme().subscribe((themeData: ITheme[]) => {
      const theme = themeData.find((ele) => ele.default == true);
      if (theme) {
        this.dataSubject.next(theme);
      }
    });
  }

  setSelectedTheme(theme: ITheme): void {
    this.dataSubject.next(theme);
  }
}
