import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ITheme } from '../models/theme';
import { HttpClient } from '@angular/common/http';
import { baseUrl } from '../global/http-url';
@Injectable({
  providedIn: 'root',
})
export class ThemeService {
  private themeDataUrl = `${baseUrl}/themeData`;
  constructor(private http: HttpClient) {}

  getAllTheme(): Observable<ITheme[]> {
    return this.http.get<ITheme[]>(this.themeDataUrl);
  }

  deleteTheme(id: string): Observable<any> {
    return this.http.delete(`${this.themeDataUrl}/${id}`, {
      responseType: 'text',
    });
  }

  addTheme(theme: ITheme): Observable<any> {
    return this.http.post(`${this.themeDataUrl}`, theme);
  }

  editTheme(id: string, theme: ITheme): Observable<any> {
    return this.http.put(`${this.themeDataUrl}/${id}`, theme);
  }

  getThemeById(id: string): Observable<ITheme> {
    return this.http.get<ITheme>(`${this.themeDataUrl}/${id}`);
  }
}
