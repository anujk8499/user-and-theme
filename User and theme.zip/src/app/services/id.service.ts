import { Injectable } from '@angular/core';
import { ThemeService } from './theme.service';
import { ITheme } from '../models/theme';
import { UserService } from './user.service';
import { IUser } from '../models/user';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root',
})
export class IdService {
  themes!: ITheme[];

  constructor(
    private readonly themeService: ThemeService,
    private readonly userService: UserService
  ) {}

  getNextThemeId(): Observable<number> {
    return new Observable<number>((observer) => {
      let currentId = -1000;
      this.themeService.getAllTheme().subscribe((themeData: ITheme[]) => {
        themeData.forEach((theme: ITheme) => {
          currentId = Math.max(currentId, Number(theme.id));
        });
        observer.next(currentId + 1);
        observer.complete();
      });
    });
  }

  getNextUserId(): Observable<number> {
    return new Observable<number>((observer) => {
      let currentId = -1000;
      this.userService.getAllUserData().subscribe((userData: IUser[]) => {
        userData.forEach((user: IUser) => {
          currentId = Math.max(currentId, Number(user.id));
        });
        observer.next(currentId + 1);
        observer.complete();
      });
    });
  }
}
