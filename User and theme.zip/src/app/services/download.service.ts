import { Injectable } from '@angular/core';
import { IHeader } from '../models/header';

@Injectable({
  providedIn: 'root',
})
export class DownloadService {
  constructor() {}

  exportToCSV(tableHaeaders: IHeader[], data: any): void {
    const csvData = this.convertToCSV(tableHaeaders, data);
    this.downloadCSV(csvData);
  }
  convertToCSV(tableHeaders: IHeader[], tableData: any[]): string {
    let header: string[] = [];
    let csvHeader: string = '';
    tableHeaders.forEach((tHeader) => {
      if (tHeader.isVisiable) {
        header.push(tHeader.label);
      }
    });
    csvHeader = header.join(',');
    let content: string[] = [];
    let currentContentString: string[] = [];
    tableData.forEach((rowData) => {
      if (rowData['isChecked']) {
        tableHeaders.forEach((header) => {
          if (header.key == 'hobbies' && header.isVisiable) {
            let hobbies: string[] = rowData[header.key];
            let csvHobbies: string = hobbies.join(',');
            currentContentString.push(`"${csvHobbies}"`);
            csvHobbies = '';
          } else if (header.isVisiable) {
            currentContentString.push(rowData[header.key]);
          }
        });
      }

      if (currentContentString.length > 0)
        content.push(currentContentString.join(','));
      currentContentString = [];
    });

    return `${csvHeader}\n${content.join('\n')}`;
  }

  downloadCSV(csvData: string): void {
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'exported_data.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }
}
