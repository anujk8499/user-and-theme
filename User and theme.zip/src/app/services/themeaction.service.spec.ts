import { TestBed } from '@angular/core/testing';

import { ThemeactionService } from './themeaction.service';

describe('ThemeactionService', () => {
  let service: ThemeactionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ThemeactionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
