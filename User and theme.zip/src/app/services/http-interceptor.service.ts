import { Injectable } from '@angular/core';
import {
  HttpEvent,
  HttpInterceptor,
  HttpHandler,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse,
} from '@angular/common/http';
import { Observable, finalize } from 'rxjs';
import { IdleTimeoutService } from './idle-timeout.service';
import { Router } from '@angular/router';
import { LoaderService } from './loader.service';
@Injectable({
  providedIn: 'root',
})
export class HttpInterceptorService {
  constructor(
    private readonly idleTimeoutService: IdleTimeoutService,
    private router: Router,
    private readonly loaderSerice: LoaderService
  ) {}

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    let currentRoute = this.router.url;
    this.loaderSerice.showLoader();
    if (currentRoute != '/login' && currentRoute != '/') {
      this.idleTimeoutService.resetTimeout();
    }

    return next
      .handle(request)
      .pipe(finalize(() => this.loaderSerice.hideLoader()));
  }
}
