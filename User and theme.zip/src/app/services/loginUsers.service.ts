import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ILoginUser } from '../models/loginUser';
import { ICountry } from '../models/country';
import { HttpClient } from '@angular/common/http';
import { baseUrl } from '../global/http-url';
@Injectable({
  providedIn: 'root',
})
export class LoginUserService {
  private userUrl: string = `${baseUrl}/usersLogin`;

  constructor(private http: HttpClient) {}

  getUserDetail(): Observable<ILoginUser[]> {
    return this.http.get<ILoginUser[]>(this.userUrl);
  }
}
