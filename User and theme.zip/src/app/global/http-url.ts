export const baseUrl: string = 'http://localhost:3000';
