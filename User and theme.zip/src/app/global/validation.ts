export const emailRegx: string =
  '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+.[a-zA-Z]{2,}$';
export const nameRegx: RegExp = /^[a-zA-Z ]+$/;
export const contactRegx: RegExp = /^\d{10}$/;
export const pincodeRegx: string = '^[1-9][0-9]{5}$';
export const cityRegx: string = '^[A-Za-z ]+$';
export const yearRegx: RegExp = /^(19[0-9]\d|20[0-1]\d|202[0-4])$/;
export const marksRegex: RegExp = /^(\d{1,2}(\.\d{1,2})?|100(\.0{1,2})?)$/;
