import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-AID3MEPJ.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-RYC75T7H.js";
import "./chunk-V3MYRIN2.js";
import "./chunk-AWCQBJDB.js";
import "./chunk-LJGRNS6V.js";
import "./chunk-R4O65HR3.js";
import "./chunk-P6UOXV5L.js";
import "./chunk-UXKWLGGS.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-RHEJHBAM.js";
import "./chunk-JPFABZP5.js";
import "./chunk-MPIWYBMR.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-GLLL6ZVE.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
