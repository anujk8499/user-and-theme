import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-2SKI554Q.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-RYC75T7H.js";
import "./chunk-V3MYRIN2.js";
import "./chunk-UXKWLGGS.js";
import "./chunk-RHEJHBAM.js";
import "./chunk-JPFABZP5.js";
import "./chunk-MPIWYBMR.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-GLLL6ZVE.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
